# @keycardlabs/mcp-oauth

`@keycardlabs/mcp-oauth` implements authorization capabilities for the [Model
Context Protocol](https://modelcontextprotocol.io/) (MCP).  This package
implements [OAuth 2.0](https://datatracker.ietf.org/doc/html/rfc6749), along
with various standard extensions, to provide both basic and high-security
protection for MCP servers.  This package integrates with the [MCP TypeScript
SDK](https://github.com/modelcontextprotocol/typescript-sdk), making it easy to:

  - Build MCP clients that securely connect to any MCP server
  - Create MCP servers that securely expose resources, prompts and tools
  - Incorporate authorization context when responding to MCP protocol messages

## Install

```sh
$ npm install @keycardlabs/mcp-oauth
```

## Usage

### Protecting Servers

Protect MCP servers by using `mcpAuthMetadataRouter()`.  This will add the
following routes:

  - `/.well-known/oauth-protected-resource` - Responds with [OAuth 2.0 Protected
    Resource Metadata](https://datatracker.ietf.org/doc/html/rfc9728).  MCP
    clients will fetch this metadata to discover which authorization server
    protects the MCP server, as configured by the `oauthMetadata.issuer` option.

  - `/.well-known/oauth-authorization-server` - Responds with [OAuth 2.0
    Authorization Server Metadata](https://datatracker.ietf.org/doc/html/rfc8414).
    This is needed for backwards compatibility with MCP clients supporting
    version [2025-03-26](https://modelcontextprotocol.io/specification/2025-03-26)
    of the protocol.  This metadata will be fetched from the authorization
    server, as configured by the `oauthMetadata.issuer` option, and returned to
    the client.

Add authorization middleware to MCP transport endpoints ([Streamable HTTP](https://github.com/modelcontextprotocol/typescript-sdk?tab=readme-ov-file#streamable-http)
or [HTTP with SSE](https://github.com/modelcontextprotocol/typescript-sdk?tab=readme-ov-file#server-side-compatibility))
with `requireBearerAuth()`.  This will authorize requests from MCP clients by
verifying access tokens issued by the authorization server.  Unauthorized
requests will be rejected with a HTTP `401 Unauthorized` or `403 Forbidden`
response.  MCP clients will handle this response by initiating an OAuth
authorization flow with the authorization server (discovered via the metadata
endpoints) in order to obtain an access token.

```ts
import express from 'express';
import { mcpAuthMetadataRouter } from '@keycardlabs/mcp-oauth/server/auth/router.js';
import { requireBearerAuth } from '@keycardlabs/mcp-oauth/server/auth/middleware/bearerAuth.js';

const app = express();

// Add OAuth metadata routes to the MCP server
app.use(mcpAuthMetadataRouter({
  oauthMetadata: {
    issuer: 'https://example.keycard.cloud'
  },
  resourceName: 'MCP Example Server',
  scopesSupported: ['mcp:tools']
}));

const authMiddleware = requireBearerAuth({
  requiredScopes: ['mcp:tools']
});

// Streamable HTTP endpoint
app.post('/mcp', authMiddleware, async (req, res) => {
  // ...
});
```

### Authorize Tool Calls

Once authorization has been added to the underlying HTTP transport, tools,
resources, and other handlers can incorporate authentication and authorization
information by processing the `authInfo` argument.

```ts
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";

const server = new McpServer({
  name: "whoami",
  version: "1.0.0",
});

server.registerTool(
  "whoami",
  { title: "User information", description: "Get information about the authenticated user" },
  async ({ authInfo }) => {
    return { content: [{ type: "text", text: `You are ${authInfo.extra.name}` }] }
  },
);
```

### Connecting Clients

Client connections to MCP servers can be securely authenticated and authorized
using OAuth 2.0 by passing an `authProvider` to the transport layer.

`@modelcontextprotocol/sdk` exports an abstract `OAuthClientProvider` interface
that must be implemented in by applications.  `@keycardlabs/mcp-oauth`
implements this interface and can be used directly by applications.  The
implementation provides high-security authentication and pluggable storage
engines for storing keys, tokens, and other artifacts resulting from
authorization flows.

```ts
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { BaseOAuthClientProvider } from "@keycardlabs/mcp-oauth/client/auth/providers/base.js";

const authProvider = new BaseOAuthClientProvider({
  client_name: "example-client"
});
authProvider.tokensStore = new InMemoryTokensStore();

const transport = new StreamableHTTPClientTransport(
  new URL("https://mcp.example.com/mcp"),
  {
    authProvider: authProvider
  }
);

const client = new Client(
  {
    name: "example-client",
    version: "1.0.0"
  }
);

await client.connect(transport);
```
